import Carrusel from "../../components/Carrusel/Carrusel"


function Home () {
    return ( 
        <Carrusel/>
    )
}

export default Home