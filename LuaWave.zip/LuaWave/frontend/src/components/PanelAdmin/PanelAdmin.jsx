import style from '../PanelAdmin/PanelAdmin.module.css'

function PanelAdmin () {
    return (
        <>
        <p>s</p>
        <p>s</p>
        <p>s</p>
        

        <h1>Panel Admin</h1>
        </>
    )
}

export default PanelAdmin
